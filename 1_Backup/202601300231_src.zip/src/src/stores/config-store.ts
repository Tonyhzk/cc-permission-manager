import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { invoke } from '@tauri-apps/api/core';
import { join } from '@tauri-apps/api/path';
import type { PermissionsConfig, CategoryName, ModeName, ModePermissions } from '@/types';
import { DEFAULT_PERMISSIONS_CONFIG } from '@/lib/constants';

interface ConfigState {
  // 配置数据
  config: PermissionsConfig;
  originalConfig: PermissionsConfig | null;

  // 状态
  isLoading: boolean;
  isSaving: boolean;
  hasChanges: boolean;
  error: string | null;

  // 操作
  setConfig: (config: PermissionsConfig) => void;
  updateModePermission: (mode: ModeName, field: keyof ModePermissions, value: number) => void;
  addCategoryItem: (category: CategoryName, type: 'tools' | 'commands', item: string) => void;
  removeCategoryItem: (category: CategoryName, type: 'tools' | 'commands', item: string) => void;
  updateCategoryItems: (category: CategoryName, type: 'tools' | 'commands', items: string[]) => void;
  updateNotificationSetting: (path: string, value: unknown) => void;

  // 持久化
  loadConfig: () => Promise<void>;
  saveConfig: () => Promise<void>;
  resetToDefaults: () => void;
  discardChanges: () => void;
}

export const useConfigStore = create<ConfigState>()(
  devtools(
    (set, get) => ({
      // 初始状态
      config: DEFAULT_PERMISSIONS_CONFIG,
      originalConfig: null,
      isLoading: false,
      isSaving: false,
      hasChanges: false,
      error: null,

      // 设置配置
      setConfig: (config) => {
        set({
          config,
          originalConfig: JSON.parse(JSON.stringify(config)),
          hasChanges: false,
        });
      },

      // 更新模式权限
      updateModePermission: (mode, field, value) => {
        const { config } = get();
        const newConfig = {
          ...config,
          modes: {
            ...config.modes,
            [mode]: {
              ...config.modes[mode],
              [field]: value,
            },
          },
        };
        set({ config: newConfig, hasChanges: true });
      },

      // 添加分类项
      addCategoryItem: (category, type, item) => {
        const { config } = get();
        const currentItems = config.categories[category][type];
        if (currentItems.includes(item)) return;

        const newConfig = {
          ...config,
          categories: {
            ...config.categories,
            [category]: {
              ...config.categories[category],
              [type]: [...currentItems, item],
            },
          },
        };
        set({ config: newConfig, hasChanges: true });
      },

      // 移除分类项
      removeCategoryItem: (category, type, item) => {
        const { config } = get();
        const newConfig = {
          ...config,
          categories: {
            ...config.categories,
            [category]: {
              ...config.categories[category],
              [type]: config.categories[category][type].filter((i) => i !== item),
            },
          },
        };
        set({ config: newConfig, hasChanges: true });
      },

      // 批量更新分类项
      updateCategoryItems: (category, type, items) => {
        const { config } = get();
        const newConfig = {
          ...config,
          categories: {
            ...config.categories,
            [category]: {
              ...config.categories[category],
              [type]: items,
            },
          },
        };
        set({ config: newConfig, hasChanges: true });
      },

      // 更新通知设置
      updateNotificationSetting: (path, value) => {
        const { config } = get();
        const newConfig = { ...config };
        const parts = path.split('.');
        let current: Record<string, unknown> = newConfig.notifications as unknown as Record<string, unknown>;

        for (let i = 0; i < parts.length - 1; i++) {
          current = current[parts[i]] as Record<string, unknown>;
        }
        current[parts[parts.length - 1]] = value;

        set({ config: newConfig, hasChanges: true });
      },

      // 加载配置
      loadConfig: async () => {
        set({ isLoading: true, error: null });
        try {
          // 读取用户的 ~/.claude/permissions.json
          const claudeDir = await invoke<string>('get_claude_config_dir');
          const permissionsPath = await join(claudeDir, 'permissions.json');

          // 检查文件是否存在
          const exists = await invoke<boolean>('file_exists', { path: permissionsPath });

          let config: PermissionsConfig;

          if (exists) {
            // 读取用户配置
            const result = await invoke<{ success: boolean; content?: string; error?: string }>(
              'read_config_file',
              { path: permissionsPath }
            );

            if (result.success && result.content) {
              config = JSON.parse(result.content);
            } else {
              // 读取失败，使用默认配置
              config = DEFAULT_PERMISSIONS_CONFIG;
            }
          } else {
            // 文件不存在，使用默认配置
            config = DEFAULT_PERMISSIONS_CONFIG;
          }

          set({
            config,
            originalConfig: JSON.parse(JSON.stringify(config)),
            isLoading: false,
            hasChanges: false,
          });
        } catch (error) {
          set({
            error: error instanceof Error ? error.message : 'Failed to load config',
            isLoading: false,
            config: DEFAULT_PERMISSIONS_CONFIG,
            originalConfig: JSON.parse(JSON.stringify(DEFAULT_PERMISSIONS_CONFIG)),
          });
        }
      },

      // 保存配置
      saveConfig: async () => {
        set({ isSaving: true, error: null });
        try {
          const { config } = get();

          // 保存到 ~/.claude/permissions.json
          const claudeDir = await invoke<string>('get_claude_config_dir');
          const permissionsPath = await join(claudeDir, 'permissions.json');

          // 格式化 JSON
          const jsonContent = JSON.stringify(config, null, 2);

          // 写入文件
          await invoke('write_config_file', {
            path: permissionsPath,
            content: jsonContent,
          });

          set({
            originalConfig: JSON.parse(JSON.stringify(config)),
            isSaving: false,
            hasChanges: false,
          });
        } catch (error) {
          set({
            error: error instanceof Error ? error.message : 'Failed to save config',
            isSaving: false,
          });
        }
      },

      // 重置为默认值
      resetToDefaults: () => {
        set({
          config: DEFAULT_PERMISSIONS_CONFIG,
          hasChanges: true,
        });
      },

      // 放弃更改
      discardChanges: () => {
        const { originalConfig } = get();
        if (originalConfig) {
          set({
            config: JSON.parse(JSON.stringify(originalConfig)),
            hasChanges: false,
          });
        }
      },
    }),
    { name: 'config-store' }
  )
);
