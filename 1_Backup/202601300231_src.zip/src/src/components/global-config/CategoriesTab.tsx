import { useTranslation } from 'react-i18next';
import { useConfigStore } from '@/stores';
import { CategoryCard } from './CategoryCard';
import type { CategoryName } from '@/types';

const categories: CategoryName[] = [
  'read',
  'edit',
  'risky',
  'useWeb',
  'useMcp',
  'globalAllow',
  'globalDeny',
];

export function CategoriesTab() {
  const { t } = useTranslation();
  const { config, updateCategoryItems } = useConfigStore();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">{t('categories.title')}</h2>
        <p className="text-sm text-muted-foreground mt-1">
          {t('categories.description')}
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {categories.map((category) => (
          <CategoryCard
            key={category}
            name={category}
            config={config.categories[category]}
            onUpdateTools={(tools) => updateCategoryItems(category, 'tools', tools)}
            onUpdateCommands={(commands) => updateCategoryItems(category, 'commands', commands)}
          />
        ))}
      </div>
    </div>
  );
}
