import { useTranslation } from 'react-i18next';
import { useConfigStore } from '@/stores';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  Switch,
  Label,
  Input,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui';

export function NotificationsTab() {
  const { t } = useTranslation();
  const { config, updateNotificationSetting } = useConfigStore();
  const { notifications } = config;

  const soundOptions = notifications._soundOptions?.macOS || [
    'default',
    'Basso',
    'Blow',
    'Bottle',
    'Frog',
    'Funk',
    'Glass',
    'Hero',
    'Morse',
    'Ping',
    'Pop',
    'Purr',
    'Sosumi',
    'Submarine',
    'Tink',
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">{t('notifications.title')}</h2>
        <p className="text-sm text-muted-foreground mt-1">
          {t('notifications.description')}
        </p>
      </div>

      {/* Global Enable */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">{t('notifications.enabled')}</Label>
              <p className="text-sm text-muted-foreground">
                {t('notifications.enabledDesc')}
              </p>
            </div>
            <Switch
              checked={notifications.enabled === 1}
              onCheckedChange={(checked: boolean) =>
                updateNotificationSetting('enabled', checked ? 1 : 0)
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Task Completion */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">{t('notifications.onCompletion')}</CardTitle>
              <CardDescription>{t('notifications.onCompletionDesc')}</CardDescription>
            </div>
            <Switch
              checked={notifications.onCompletion.enabled === 1}
              onCheckedChange={(checked: boolean) =>
                updateNotificationSetting('onCompletion.enabled', checked ? 1 : 0)
              }
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>{t('notifications.notificationTitle')}</Label>
            <Input
              value={notifications.onCompletion.title}
              onChange={(e) =>
                updateNotificationSetting('onCompletion.title', e.target.value)
              }
            />
          </div>
          <div className="space-y-2">
            <Label>{t('notifications.message')}</Label>
            <Input
              value={notifications.onCompletion.message}
              onChange={(e) =>
                updateNotificationSetting('onCompletion.message', e.target.value)
              }
            />
          </div>
          <div className="space-y-2">
            <Label>{t('notifications.sound')}</Label>
            <Select
              value={notifications.onCompletion.sound}
              onValueChange={(value) =>
                updateNotificationSetting('onCompletion.sound', value)
              }
            >
              <SelectTrigger>
                <SelectValue placeholder={t('notifications.selectSound')} />
              </SelectTrigger>
              <SelectContent>
                {soundOptions.map((sound) => (
                  <SelectItem key={sound} value={sound}>
                    {sound}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Permission Request */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">{t('notifications.onPermissionRequest')}</CardTitle>
              <CardDescription>{t('notifications.onPermissionRequestDesc')}</CardDescription>
            </div>
            <Switch
              checked={notifications.onPermissionRequest.enabled === 1}
              onCheckedChange={(checked: boolean) =>
                updateNotificationSetting('onPermissionRequest.enabled', checked ? 1 : 0)
              }
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>{t('notifications.notificationTitle')}</Label>
            <Input
              value={notifications.onPermissionRequest.title}
              onChange={(e) =>
                updateNotificationSetting('onPermissionRequest.title', e.target.value)
              }
            />
          </div>
          <div className="space-y-2">
            <Label>{t('notifications.message')}</Label>
            <Input
              value={notifications.onPermissionRequest.message}
              onChange={(e) =>
                updateNotificationSetting('onPermissionRequest.message', e.target.value)
              }
            />
          </div>
          <div className="space-y-2">
            <Label>{t('notifications.sound')}</Label>
            <Select
              value={notifications.onPermissionRequest.sound}
              onValueChange={(value) =>
                updateNotificationSetting('onPermissionRequest.sound', value)
              }
            >
              <SelectTrigger>
                <SelectValue placeholder={t('notifications.selectSound')} />
              </SelectTrigger>
              <SelectContent>
                {soundOptions.map((sound) => (
                  <SelectItem key={sound} value={sound}>
                    {sound}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
