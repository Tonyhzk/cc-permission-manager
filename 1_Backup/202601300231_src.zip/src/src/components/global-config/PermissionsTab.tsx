import { useTranslation } from 'react-i18next';
import { useConfigStore } from '@/stores';
import { ModePermissionsCard } from './ModePermissionsCard';
import type { ModeName } from '@/types';

const modes: ModeName[] = ['plan', 'default', 'acceptEdits'];

export function PermissionsTab() {
  const { t } = useTranslation();
  const { config, updateModePermission } = useConfigStore();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">{t('modes.title')}</h2>
        <p className="text-sm text-muted-foreground mt-1">
          {t('modes.description')}
        </p>
      </div>

      <div className="grid gap-6">
        {modes.map((mode) => (
          <ModePermissionsCard
            key={mode}
            mode={mode}
            permissions={config.modes[mode]}
            onUpdate={(field, value) => updateModePermission(mode, field, value)}
          />
        ))}
      </div>
    </div>
  );
}
