#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CC Permission Manager - 开发环境切换脚本
用于在 Mac 和 Windows 之间切换 node_modules 和 target 目录
"""

import os
import sys
import platform
import shutil
from pathlib import Path

# 颜色输出
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_color(text, color=Colors.RESET):
    print(f"{color}{text}{Colors.RESET}")

def get_script_dir():
    """获取脚本所在目录"""
    return Path(__file__).parent.absolute()

def get_project_root():
    """获取项目根目录"""
    return get_script_dir().parent

def get_current_os():
    """获取当前操作系统"""
    system = platform.system().lower()
    if system == 'darwin':
        return 'mac'
    elif system == 'windows':
        return 'win'
    else:
        return 'linux'

def detect_active_env(src_dir):
    """
    检测当前激活的开发环境
    返回: 'mac', 'win', 'none', 或 'unknown'
    """
    node_modules = src_dir / 'node_modules'
    node_modules_mac = src_dir / 'node_modules_mac'
    node_modules_win = src_dir / 'node_modules_win'
    
    # 检查 node_modules 是否存在
    if not node_modules.exists():
        return 'none'
    
    # 检查哪个备份目录是空的（表示当前正在使用）
    mac_empty = not node_modules_mac.exists() or not any(node_modules_mac.iterdir())
    win_empty = not node_modules_win.exists() or not any(node_modules_win.iterdir())
    
    if mac_empty and not win_empty:
        return 'mac'
    elif win_empty and not mac_empty:
        return 'win'
    elif mac_empty and win_empty:
        # 两个都是空的，根据当前 OS 判断
        return get_current_os()
    else:
        # 两个都有内容，可能是初始状态
        return 'unknown'

def detect_active_target_env(tauri_dir):
    """检测当前激活的 Rust target 环境"""
    target = tauri_dir / 'target'
    target_mac = tauri_dir / 'target_mac'
    target_win = tauri_dir / 'target_win'
    
    if not target.exists():
        return 'none'
    
    mac_empty = not target_mac.exists() or not any(target_mac.iterdir())
    win_empty = not target_win.exists() or not any(target_win.iterdir())
    
    if mac_empty and not win_empty:
        return 'mac'
    elif win_empty and not mac_empty:
        return 'win'
    elif mac_empty and win_empty:
        return get_current_os()
    else:
        return 'unknown'

def get_dir_size(path):
    """获取目录大小（MB）"""
    if not path.exists():
        return 0
    total = 0
    try:
        for entry in path.rglob('*'):
            if entry.is_file():
                total += entry.stat().st_size
    except (PermissionError, OSError):
        pass
    return total / (1024 * 1024)

def switch_node_modules(src_dir, target_env):
    """切换 node_modules 目录"""
    node_modules = src_dir / 'node_modules'
    node_modules_mac = src_dir / 'node_modules_mac'
    node_modules_win = src_dir / 'node_modules_win'
    
    current_env = detect_active_env(src_dir)
    
    if current_env == target_env:
        print_color(f"  node_modules 已经是 {target_env} 环境", Colors.YELLOW)
        return True
    
    # 确保目标备份目录存在
    node_modules_mac.mkdir(exist_ok=True)
    node_modules_win.mkdir(exist_ok=True)
    
    # 保存当前环境
    if node_modules.exists() and current_env in ['mac', 'win']:
        backup_dir = node_modules_mac if current_env == 'mac' else node_modules_win
        print_color(f"  保存当前 {current_env} 环境到 {backup_dir.name}/...", Colors.CYAN)
        
        # 移动到备份目录
        for item in node_modules.iterdir():
            dest = backup_dir / item.name
            if dest.exists():
                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            shutil.move(str(item), str(dest))
    
    # 恢复目标环境
    restore_dir = node_modules_mac if target_env == 'mac' else node_modules_win
    if restore_dir.exists() and any(restore_dir.iterdir()):
        print_color(f"  恢复 {target_env} 环境从 {restore_dir.name}/...", Colors.CYAN)
        
        # 确保 node_modules 目录存在
        node_modules.mkdir(exist_ok=True)
        
        # 移动到 node_modules
        for item in restore_dir.iterdir():
            dest = node_modules / item.name
            if dest.exists():
                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            shutil.move(str(item), str(dest))
        
        print_color(f"  ✓ node_modules 已切换到 {target_env}", Colors.GREEN)
    else:
        print_color(f"  ! {target_env} 环境的 node_modules 不存在，需要运行 pnpm install", Colors.YELLOW)
    
    return True

def switch_target(tauri_dir, target_env):
    """切换 Rust target 目录"""
    target = tauri_dir / 'target'
    target_mac = tauri_dir / 'target_mac'
    target_win = tauri_dir / 'target_win'
    
    current_env = detect_active_target_env(tauri_dir)
    
    if current_env == target_env:
        print_color(f"  target 已经是 {target_env} 环境", Colors.YELLOW)
        return True
    
    # 确保目标备份目录存在
    target_mac.mkdir(exist_ok=True)
    target_win.mkdir(exist_ok=True)
    
    # 保存当前环境
    if target.exists() and current_env in ['mac', 'win']:
        backup_dir = target_mac if current_env == 'mac' else target_win
        print_color(f"  保存当前 {current_env} target 到 {backup_dir.name}/...", Colors.CYAN)
        
        for item in target.iterdir():
            dest = backup_dir / item.name
            if dest.exists():
                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            shutil.move(str(item), str(dest))
    
    # 恢复目标环境
    restore_dir = target_mac if target_env == 'mac' else target_win
    if restore_dir.exists() and any(restore_dir.iterdir()):
        print_color(f"  恢复 {target_env} target 从 {restore_dir.name}/...", Colors.CYAN)
        
        target.mkdir(exist_ok=True)
        
        for item in restore_dir.iterdir():
            dest = target / item.name
            if dest.exists():
                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            shutil.move(str(item), str(dest))
        
        print_color(f"  ✓ target 已切换到 {target_env}", Colors.GREEN)
    else:
        print_color(f"  ! {target_env} 环境的 target 不存在，首次编译会自动创建", Colors.YELLOW)
    
    return True

def show_status(src_dir, tauri_dir):
    """显示当前状态"""
    current_os = get_current_os()
    node_env = detect_active_env(src_dir)
    target_env = detect_active_target_env(tauri_dir)
    
    print()
    print_color("=" * 60, Colors.BLUE)
    print_color("  CC Permission Manager - 开发环境管理", Colors.BOLD)
    print_color("=" * 60, Colors.BLUE)
    print()
    
    # 当前操作系统
    os_name = {'mac': 'macOS', 'win': 'Windows', 'linux': 'Linux'}.get(current_os, current_os)
    print_color(f"  当前操作系统: {os_name}", Colors.CYAN)
    print()
    
    # node_modules 状态
    print_color("  [node_modules 状态]", Colors.BOLD)
    node_modules = src_dir / 'node_modules'
    node_modules_mac = src_dir / 'node_modules_mac'
    node_modules_win = src_dir / 'node_modules_win'
    
    active_marker = " ← 当前激活" if node_env == 'mac' else ""
    mac_size = get_dir_size(node_modules if node_env == 'mac' else node_modules_mac)
    print_color(f"    Mac:     {mac_size:.1f} MB{active_marker}", Colors.GREEN if node_env == 'mac' else Colors.RESET)
    
    active_marker = " ← 当前激活" if node_env == 'win' else ""
    win_size = get_dir_size(node_modules if node_env == 'win' else node_modules_win)
    print_color(f"    Windows: {win_size:.1f} MB{active_marker}", Colors.GREEN if node_env == 'win' else Colors.RESET)
    print()
    
    # target 状态
    print_color("  [Rust target 状态]", Colors.BOLD)
    target = tauri_dir / 'target'
    target_mac = tauri_dir / 'target_mac'
    target_win = tauri_dir / 'target_win'
    
    active_marker = " ← 当前激活" if target_env == 'mac' else ""
    mac_size = get_dir_size(target if target_env == 'mac' else target_mac)
    print_color(f"    Mac:     {mac_size:.1f} MB{active_marker}", Colors.GREEN if target_env == 'mac' else Colors.RESET)
    
    active_marker = " ← 当前激活" if target_env == 'win' else ""
    win_size = get_dir_size(target if target_env == 'win' else target_win)
    print_color(f"    Windows: {win_size:.1f} MB{active_marker}", Colors.GREEN if target_env == 'win' else Colors.RESET)
    print()
    
    # 环境匹配检查
    if node_env != current_os or target_env != current_os:
        print_color(f"  ⚠ 警告: 当前环境与操作系统不匹配！", Colors.YELLOW)
        print_color(f"    建议切换到 {os_name} 环境", Colors.YELLOW)
    else:
        print_color(f"  ✓ 环境配置正确", Colors.GREEN)
    print()
    
    return node_env, target_env

def main():
    project_root = get_project_root()
    src_dir = project_root / 'src'
    tauri_dir = src_dir / 'src-tauri'
    
    # 检查目录是否存在
    if not src_dir.exists():
        print_color(f"错误: 找不到 src 目录: {src_dir}", Colors.RED)
        sys.exit(1)
    
    while True:
        node_env, target_env = show_status(src_dir, tauri_dir)
        current_os = get_current_os()
        
        print_color("  [操作选项]", Colors.BOLD)
        print("    1. 切换到 Mac 环境")
        print("    2. 切换到 Windows 环境")
        print("    3. 自动切换到当前系统环境")
        print("    0. 退出")
        print()
        
        try:
            choice = input("  请选择 (0-3): ").strip()
        except (KeyboardInterrupt, EOFError):
            print()
            break
        
        if choice == '0':
            break
        elif choice == '1':
            target_env = 'mac'
        elif choice == '2':
            target_env = 'win'
        elif choice == '3':
            target_env = current_os
        else:
            print_color("  无效选择，请重试", Colors.RED)
            continue
        
        print()
        print_color(f"  正在切换到 {target_env} 环境...", Colors.CYAN)
        print()
        
        # 切换 node_modules
        print_color("  [切换 node_modules]", Colors.BOLD)
        switch_node_modules(src_dir, target_env)
        print()
        
        # 切换 target
        print_color("  [切换 Rust target]", Colors.BOLD)
        switch_target(tauri_dir, target_env)
        print()
        
        print_color("  切换完成！", Colors.GREEN)
        print()
        input("  按 Enter 继续...")

if __name__ == '__main__':
    main()
