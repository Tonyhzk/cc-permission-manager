import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { invoke } from '@tauri-apps/api/core';
import { platform } from '@tauri-apps/plugin-os';

export type PermissionStatus = 'checking' | 'granted' | 'denied' | 'not-applicable';

interface PermissionState {
  // 权限状态
  permissionStatus: PermissionStatus;
  // 是否显示权限对话框
  showPermissionDialog: boolean;

  // 操作
  setPermissionStatus: (status: PermissionStatus) => void;
  setShowPermissionDialog: (show: boolean) => void;
  checkPermission: (workspacePath: string | null) => Promise<boolean>;
}

/**
 * 检查路径是否在受保护文件夹中
 */
function isInProtectedFolder(path: string): boolean {
  return (
    path.includes('/Documents/') ||
    path.includes('/Desktop/') ||
    path.includes('/Downloads/')
  );
}

export const usePermissionStore = create<PermissionState>()(
  devtools(
    (set) => ({
      permissionStatus: 'checking',
      showPermissionDialog: false,

      setPermissionStatus: (status) => {
        set({ permissionStatus: status });
      },

      setShowPermissionDialog: (show) => {
        set({ showPermissionDialog: show });
      },

      /**
       * 检查 macOS 文件访问权限
       * @param workspacePath 工作目录路径
       * @returns 是否有访问权限（true=有权限，可以继续加载；false=无权限，已显示对话框）
       */
      checkPermission: async (workspacePath: string | null): Promise<boolean> => {
        try {
          const currentPlatform = platform();

          // 非 macOS 或无工作目录，直接返回有权限
          if (currentPlatform !== 'macos' || !workspacePath) {
            set({ permissionStatus: 'not-applicable', showPermissionDialog: false });
            return true;
          }

          // 不在受保护文件夹中，直接返回有权限
          if (!isInProtectedFolder(workspacePath)) {
            set({ permissionStatus: 'not-applicable', showPermissionDialog: false });
            return true;
          }

          set({ permissionStatus: 'checking' });

          // 调用后端检查权限（这不会触发系统弹窗）
          const hasAccess = await invoke<boolean>('check_macos_file_access', {
            testPath: workspacePath
          });

          if (hasAccess) {
            set({ permissionStatus: 'granted', showPermissionDialog: false });
            return true;
          } else {
            // 权限被拒绝，显示应用内对话框
            set({ permissionStatus: 'denied', showPermissionDialog: true });
            return false;
          }
        } catch (error) {
          console.error('Failed to check file access:', error);
          // 检查失败时，假设有权限，让用户自己决定
          set({ permissionStatus: 'not-applicable', showPermissionDialog: false });
          return true;
        }
      },
    }),
    { name: 'permission-store' }
  )
);
